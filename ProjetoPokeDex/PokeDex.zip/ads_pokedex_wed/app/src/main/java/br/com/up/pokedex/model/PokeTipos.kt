package br.com.up.pokedex.model

data class PokeTipos(
    val types : PokeTypes
)

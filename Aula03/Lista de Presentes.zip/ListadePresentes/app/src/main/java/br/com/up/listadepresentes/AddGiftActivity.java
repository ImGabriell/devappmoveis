package br.com.up.listadepresentes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddGiftActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_gift);
    }
}
package br.com.up.listadepresentes.repositorios;

import java.util.ArrayList;

import br.com.up.listadepresentes.models.Presente;

public class GiftRepository
{

    private static GiftRepository repository;
    private ArrayList<Presente> presentes = new ArrayList<>();

    public static GiftRepository getInstance()
    {

        if(repository == null)
        {
            repository = new GiftRepository();
        }

        return repository;

    }

    private GiftRepository(){}

    {

    }

    public void save(Presente presente)
    {
        presentes.add(presente);
    }

    public void delete(Presente presente)
    {
        presentes.remove(presente);
    }

    public ArrayList<Presente> getAll()
    {
        return presentes;
    }

    public void update(int index, Presente presente)
    {
        presentes.set(index, presente);
    }

    public Presente getByIndex(int index)
    {
        return presentes.get(index);
    }

}

package br.com.up.listadepresentes.models

data class Presente
(
        var nome:String,
        var presente:String,
        var descricao:String
)

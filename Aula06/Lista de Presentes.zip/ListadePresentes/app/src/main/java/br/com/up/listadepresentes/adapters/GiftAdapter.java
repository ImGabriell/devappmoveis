package br.com.up.listadepresentes.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import br.com.up.listadepresentes.R;
import br.com.up.listadepresentes.models.Presente;

public class GiftAdapter extends RecyclerView.Adapter<GiftAdapter.GiftViewHolder>
{

    private ArrayList<Presente> presentes;

    public GiftAdapter(ArrayList<Presente> presentes)
    {
        this.presentes = presentes;
    }

    @NonNull
    @Override
    public GiftViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        View layout = layoutInflater.inflate
                (
                        R.layout.view_item_presente,
                        parent,
                        false
                );

        return new GiftViewHolder(layout);
    }

    @Override
    public void onBindViewHolder(@NonNull GiftViewHolder holder, int position)
    {
        Presente presente = presentes.get(position);

        TextView textViewNome = holder.itemView.findViewById(R.id.text_presente_nome);
        TextView textViewPresente = holder.itemView.findViewById(R.id.text_presente_title);
        TextView textViewDescricao = holder.itemView.findViewById(R.id.text_presente_descricao);

        textViewNome.setText(presente.getNome());
        textViewPresente.setText(presente.getPresente());
        textViewDescricao.setText(presente.getDescricao());
    }

    @Override
    public int getItemCount()
    {
        return presentes.size();
    }

    public static class GiftViewHolder extends RecyclerView.ViewHolder
    {
        public GiftViewHolder(@NonNull View itemView)
        {
            super(itemView);
        }
    }
}

package br.com.up.listadepresentes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import br.com.up.listadepresentes.adapters.GiftAdapter;
import br.com.up.listadepresentes.models.Presente;
import br.com.up.listadepresentes.repositorios.GiftRepository;

public class MainActivity extends AppCompatActivity
{

    private FloatingActionButton fabAddGift;
    private RecyclerView recyclerViewPresentes;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewPresentes = findViewById(R.id.recycler_presente);

        fabAddGift = findViewById(R.id.fab_add_gift);

        recyclerViewPresentes.setLayoutManager
                (
                new LinearLayoutManager
                        (
                                this,
                                RecyclerView.VERTICAL,
                                false

                        )

                );

        ArrayList<Presente> presentes = GiftRepository.getInstance().getAll();

        fabAddGift.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent

                        (
                        getApplicationContext(),
                        AddGiftActivity.class
                        );

                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume()
    {
        super.onResume();

        ArrayList<Presente> presentes = GiftRepository.getInstance().getAll();

        if(presentes.size() > 0)
        {

        }

        recyclerViewPresentes.setAdapter(new GiftAdapter(presentes));

    }
}


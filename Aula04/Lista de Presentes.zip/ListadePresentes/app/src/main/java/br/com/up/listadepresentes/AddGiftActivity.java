package br.com.up.listadepresentes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class AddGiftActivity extends AppCompatActivity
{

    private TextInputLayout inputLayoutNome;
    private TextInputLayout inputLayoutPresente;
    private TextInputLayout inputLayoutDescricao;

    private TextInputEditText inputEditTextNome;
    private TextInputEditText inputEditTextPresente;
    private TextInputEditText inputEditTextDescricao;

    private Button buttonAddPresente;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_gift);

        inputLayoutNome = findViewById(R.id.input_layout_nome);
        inputLayoutPresente = findViewById(R.id.input_layout_presente);
        inputLayoutDescricao = findViewById(R.id.input_layout_descricao);

        inputEditTextNome = findViewById(R.id.input_text_nome);
        inputEditTextPresente = findViewById(R.id.input_text_presente);
        inputEditTextDescricao = findViewById(R.id.input_text_descricao);

        buttonAddPresente = findViewById(R.id.button);

        buttonAddPresente.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                savePresente();
            }
        });
    }

    private void savePresente()
    {
        String nome = inputEditTextNome.getText().toString();
        String presenteNome = inputEditTextPresente.getText().toString();
        String descricao = inputEditTextDescricao.getText().toString();



    }

}